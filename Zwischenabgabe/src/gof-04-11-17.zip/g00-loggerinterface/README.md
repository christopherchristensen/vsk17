# Logger Interface

Definition des Logger-Interface für das Logger-Projekt von VSK-17HS.