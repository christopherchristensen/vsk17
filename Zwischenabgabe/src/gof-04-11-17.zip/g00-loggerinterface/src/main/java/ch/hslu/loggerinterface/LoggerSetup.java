package ch.hslu.loggerinterface;

/**
 * Defines an interface to configure and create a Logger object
 */
public interface LoggerSetup {

    /**
     * Create a unnamed logger
     * @param host The hostname or string representation of an ip of the logger server
     * @param port The port on the server where the logger server is accessible
     * @return A logger object which can be used to log messages
     */
    Logger createLogger(String host, int port);

    /**
     * Create a named logger
     * @param host The hostname or string representation of an ip of the logger server
     * @param port The port on the server where the logger server is accessible
     * @param name The name of the logger
     * @return A logger object which can be used to log messages
     */
    Logger createLogger(String host, int port, String name);
}
