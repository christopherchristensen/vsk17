package ch.hslu.loggerinterface;

/**
 * Define the interface to log messages
 */
public interface Logger {

    /**
     * Set the minimum level for LogMessages which will be reported to the server
     * @param logLevel The minimum level which should be reported
     */
    void setReportLevel(LogLevel logLevel);

    /**
     * Send a message to the logger
     * @param logLevel A classification of the message
     * @param message The message to log
     */
    void log(LogLevel logLevel, String message);

    /**
     * Send an throwable to the logger
     * @param logLevel A classification of the throwable
     * @param throwable The throwable to log
     */
    void log(LogLevel logLevel, Throwable throwable);
}
