package ch.hslu.loggerinterface;

/**
 * Defines an enum to classify LogMessages
 */
public enum LogLevel {

    /**
     * Represents a debug message
     */
    DEBUG(10),

    /**
     * Represents a informational message
     */
    INFO(20),

    /**
     * Represents a warning
     */
    WARNING(30),

    /**
     * Represents a error in the application
     */
    ERROR(40),

    /**
     * Represents a critical error in the application
     */
    CRITICAL(50);

    /**
     * The internal code of the LogLevel
     */
    private int code;

    /**
     * Define a new LogLevel with the given code
     * @param code The code for the new LogLevel
     */
    private LogLevel(int code) {
        this.code = code;
    }

    /**
     * Get the code of the current LogLevel
     * @return The internal code
     */
    public int getCode() {
        return code;
    }

}
