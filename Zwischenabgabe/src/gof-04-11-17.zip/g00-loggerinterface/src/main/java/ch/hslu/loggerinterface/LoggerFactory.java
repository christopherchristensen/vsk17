package ch.hslu.loggerinterface;

/**
 * Defines a static factory to create a LoggerSetup object
 */
public class LoggerFactory {

    /**
     * Create a LoggerSetup compatible object based on the FQDN of an interface implementation
     * @param fullQualifiedName A string representation of the FQDN to an implementation of the LoggerSetup interface
     * @return A LoggerSetup to configure a logger
     * @throws ClassNotFoundException Will be throw if the class can no be found
     * @throws IllegalAccessException Will be throw if the class is not accessibly
     * @throws InstantiationException Will be thrown if the class can not been instantiated
     */
    public static LoggerSetup getLoggerSetup(String fullQualifiedName) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        Class loggerSetup = Class.forName(fullQualifiedName);
        return (LoggerSetup)loggerSetup.newInstance();
    }
}
