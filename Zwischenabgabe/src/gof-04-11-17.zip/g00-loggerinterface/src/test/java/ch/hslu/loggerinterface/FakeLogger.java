package ch.hslu.loggerinterface;

public class FakeLogger implements Logger {
    @Override
    public void setReportLevel(LogLevel logLevel) {

    }

    @Override
    public void log(LogLevel logLevel, String message) {

    }

    @Override
    public void log(LogLevel logLevel, Throwable throwable) {

    }
}
