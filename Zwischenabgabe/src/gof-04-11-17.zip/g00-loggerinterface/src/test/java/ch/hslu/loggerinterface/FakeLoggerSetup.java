package ch.hslu.loggerinterface;

public class FakeLoggerSetup implements LoggerSetup {
    @Override
    public Logger createLogger(String host, int port) {
        return new FakeLogger();
    }

    @Override
    public Logger createLogger(String host, int port, String name) {
        return new FakeLogger();
    }
}
