package ch.hslu.loggerinterface;

import org.junit.Test;

import static org.junit.Assert.*;

public class LoggerFactoryTest {
    @Test
    public void get_a_logger_setup_from_the_factory() {
        try {
            LoggerSetup setup = LoggerFactory.getLoggerSetup("ch.hslu.loggerinterface.FakeLoggerSetup");
            Logger logger = setup.createLogger("localhost", 54321);
            assertNotNull(logger);
        } catch (Exception e) {
            fail("Can not instantiate a LoggerSetup object");
        }
    }

}