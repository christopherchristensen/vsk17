package ch.hslu.loggerinterface;

import org.junit.Test;

import static org.junit.Assert.*;

public class LogLevelTest {
    @Test
    public void log_level_code_matches_specs() {
        assertEquals(10, LogLevel.DEBUG.getCode());
        assertEquals(20, LogLevel.INFO.getCode());
        assertEquals(30, LogLevel.WARNING.getCode());
        assertEquals(40, LogLevel.ERROR.getCode());
        assertEquals(50, LogLevel.CRITICAL.getCode());
    }
}