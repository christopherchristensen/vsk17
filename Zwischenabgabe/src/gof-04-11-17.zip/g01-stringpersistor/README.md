[![Build Status](https://jenkins-vsk.el.eee.intern/jenkins/job/g01-stringpersistor/badge/icon)](https://jenkins-vsk.el.eee.intern/jenkins/job/g01-stringpersistor)

# StringPersistor

Implementation der stringpersistor-api für das Logger-Projekt von VSK-17HS.