package ch.hslu.vsk.g01.stringpersistor;

import ch.hslu.vsk.stringpersistor.api.PersistedString;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.nio.charset.Charset;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;


public class StringPersistor implements ch.hslu.vsk.stringpersistor.api.StringPersistor {

    private static final Logger LOGGER = LogManager.getLogger(StringPersistor.class);
    private List<PersistedString> persistedStringList;
    private File logFile;

    public StringPersistor() {this.persistedStringList = new ArrayList<>();}

    public void setFile(final File logFile) {
        this.logFile=logFile;
    }

    @Override
    public void save(final Instant instant, final String s) {
        try(final PrintWriter printwriter = new PrintWriter(new BufferedWriter(
                new FileWriter(this.logFile, true)))) {

            printwriter.println(s);

        } catch(FileNotFoundException exception) {
            LOGGER.error(exception.getMessage(), exception);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // TODO: get implementation for viewer (James)
    @Override
    public List<PersistedString> get(int i) {

        if(new File(this.logFile.getPath()).exists()) {
            try(final BufferedReader bufferedReader =
                        new BufferedReader(new InputStreamReader(new FileInputStream(this.logFile.getPath()),
                                Charset.forName("UTF-8"))))
            {
                String line;
                while((line = bufferedReader.readLine()) != null) {
                    String instantAsString = line.substring(0,24);

                    Instant instantFromString = Instant.parse(instantAsString);
                    String logString = line.substring(26);

                    LOGGER.info(instantAsString);
                    LOGGER.info(logString); // TODO: put info in list
                }
            } catch(IOException exception) {
                LOGGER.error(exception.getMessage(), exception);
            }
        }

        List<PersistedString> list = new ArrayList<>();
        Instant instant = Instant.now();
        list.add(new PersistedString(instant,"hello"));
        return list; // TODO: return only (int i) amount of last entries
    }

    // TODO: only used for JUnit tests (maybe delete after testing)
    public File getFile() {
        return this.logFile;
    }
}