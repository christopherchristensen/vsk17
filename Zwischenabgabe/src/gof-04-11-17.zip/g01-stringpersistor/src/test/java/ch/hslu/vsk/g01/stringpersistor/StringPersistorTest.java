package ch.hslu.vsk.g01.stringpersistor;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;

import java.io.File;
import java.time.Instant;

import static org.junit.Assert.*;

public class StringPersistorTest {

    private static Logger LOG = LogManager.getLogger(StringPersistorTest.class);

    @Test
    public void setFile() throws Exception {
        // Arrange
        StringPersistor stringPersistor = new StringPersistor();
        File file = new File("TestFile.txt");

        // Act
        stringPersistor.setFile(file);

        // Assert
        assertEquals("TestFile.txt", stringPersistor.getFile().getPath());

        // Revert
        LOG.info(file.delete());
    }

    @Test
    public void save() throws Exception {
        // Arrange
        StringPersistor stringPersistor = new StringPersistor();
        File file = new File("TestFile.txt");
        Instant instant = Instant.now();
        String logMessage = "LOGLEVEL: --, MESSAGE: --";

        // PreAssert
        assertEquals(file.length(),0);

        // Act
        stringPersistor.setFile(file);
        stringPersistor.save(instant,logMessage);

        // Assert
        assertEquals(true,file.length()>0);

        // Revert
        LOG.info(file.delete());
    }

    @Test
    public void get() throws Exception {
    }

}