package ch.hslu.vsk.g01.loggerserver;

import ch.hslu.vsk.g01.loggercommon.LogMessage;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The LogServer provides a socket to which clients can connect to.
 * For every received message a Thread is created to pass the message further
 */
public class LoggerServer {

    private static final Logger LOGGER = LogManager.getLogger(LoggerServerSocket.class);

    public static void main(final String[] args) {

        try {

            final ExecutorService executor = Executors.newFixedThreadPool(5);
            final LogWriterAdapter logWriterAdapter = new LogWriterAdapter();
            final ServerSocket listen = LoggerServerSocket.create();

            while (!listen.isClosed()) {
                try {
                    Socket socket = listen.accept();
                    InputStream inputStream = socket.getInputStream();
                    ObjectInputStream ois = new ObjectInputStream(inputStream);
                    LogMessage message; // TODO Melvin

                    while ((message = (LogMessage) ois.readObject()) != null) {
                        message.setReceived();
                        LOGGER.log(Level.DEBUG, message.getMessage());

                        final LogHandler handler = new LogHandler(message, logWriterAdapter);
                        executor.execute(handler);
                    }

                    inputStream.close();
                    socket.close();
                } catch (EOFException e) {
                    LOGGER.log(Level.ERROR, "Client disconnected socket...");
                    e.printStackTrace();
                }
            }
            listen.close();
        } catch(Exception e){
            LOGGER.log(Level.ERROR, "Server cannot be started because address is already in use");
            e.printStackTrace();
        }
    }
}
