package ch.hslu.vsk.g01.loggerserver;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.util.Properties;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LoggerServerSocket {

    private static final Logger LOGGER = LogManager.getLogger(LoggerServerSocket.class);

    private static String host = "127.0.0.1";
    private static int port = 54321;
    private static int amount = 10;

    private static void loadConfigFile() {
        try {
            InputStream file = LoggerServerSocket.class.getClassLoader().getResourceAsStream("config.properties");
            Properties prop = new Properties();
            prop.load(file);
            host = prop.getProperty("host");
            port = Integer.parseInt(prop.getProperty("port"));
            amount = Integer.parseInt(prop.getProperty("amount"));
        }
        catch (IOException|NullPointerException ex) {
            LOGGER.log(Level.WARN, "Config file not found, default values will be used!");
        }
    }

    public static ServerSocket create() throws IOException {
        loadConfigFile();

        InetAddress address = InetAddress.getByName(host);
        return new ServerSocket(port, amount, address);
    }
}
