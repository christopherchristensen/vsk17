package ch.hslu.vsk.g01.loggerserver;

import ch.hslu.vsk.g01.loggercommon.LogMessage;
import ch.hslu.vsk.g01.stringpersistor.StringPersistor;

import java.io.File;
import java.time.Instant;

/**
 * Adapter class for the String Persistor
 */
public class LogWriterAdapter {

    private StringPersistor stringPersistor;

    public LogWriterAdapter() throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        Class persistor = Class.forName("ch.hslu.vsk.g01.stringpersistor.StringPersistor");
        stringPersistor = (StringPersistor) persistor.newInstance();

        File file = new File("LogFile.txt");
        stringPersistor.setFile(file);
    }

    public void writeLogMessage(LogMessage logMessage){
        Instant instant = logMessage.getCreatedAt();
        String message = logMessage.getReceivedAt()+";"+logMessage.getCreatedAt()+";" + logMessage.getLogLevel() + ";" + logMessage.getMessage();

        stringPersistor.save(instant, message);
    }
}
