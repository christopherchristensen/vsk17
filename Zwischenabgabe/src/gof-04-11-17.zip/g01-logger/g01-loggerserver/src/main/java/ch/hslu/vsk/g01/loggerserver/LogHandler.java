package ch.hslu.vsk.g01.loggerserver;

import ch.hslu.vsk.g01.loggercommon.LogMessage;
import ch.hslu.vsk.stringpersistor.api.StringPersistor;
import sun.rmi.runtime.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;

/**
 * This handler is made to execute the passing to the Stringpersistor
 */
public class LogHandler implements Runnable {

    private final LogMessage message;
    private final LogWriterAdapter logWriterAdapter;

    public LogHandler(final LogMessage message, final LogWriterAdapter logWriterAdapter) {
        this.message = message;
        this.logWriterAdapter = logWriterAdapter;
    }

    @Override
    public void run() {
        logWriterAdapter.writeLogMessage(message);
    }
}