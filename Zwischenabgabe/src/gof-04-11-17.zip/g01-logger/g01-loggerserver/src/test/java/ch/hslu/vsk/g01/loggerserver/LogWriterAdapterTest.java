package ch.hslu.vsk.g01.loggerserver;

import ch.hslu.loggerinterface.LogLevel;
import ch.hslu.vsk.g01.loggercommon.LogMessage;
import org.junit.Test;

import java.io.File;

import static org.junit.Assert.*;

public class LogWriterAdapterTest {

    @Test
    public void writeLogMessage() throws Exception {
        // Arrange
        File file = new File("LogFile.txt");
        LogWriterAdapter logWriterAdapter = new LogWriterAdapter();
        LogLevel logLevel = LogLevel.DEBUG;
        String logString = "New population created";
        LogMessage logMessage = new LogMessage(logLevel,logString);

        // PreAssert
        assertEquals(true, file.length()==0);

        // Act
        logWriterAdapter.writeLogMessage(logMessage);

        // Assert
        assertEquals(false,file.length()==0);

        // Revert
        file.delete();
    }

}