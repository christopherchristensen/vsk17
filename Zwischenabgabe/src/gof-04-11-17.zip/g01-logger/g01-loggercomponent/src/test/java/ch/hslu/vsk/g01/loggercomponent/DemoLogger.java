package ch.hslu.vsk.g01.loggercomponent;

import ch.hslu.loggerinterface.LogLevel;

public class DemoLogger {

    public static void main(final String[] args) {
        BaseLogger logger = new BaseLogger();
        logger.log(LogLevel.DEBUG, "TEST1");
        logger.log(LogLevel.DEBUG, "TEST2");
        logger.log(LogLevel.DEBUG, "TEST3");
        logger.log(LogLevel.DEBUG, "TEST4");
    }
}
