package ch.hslu.vsk.g01.loggercomponent.fakes;

import ch.hslu.loggerinterface.LogLevel;
import ch.hslu.vsk.g01.loggercomponent.BaseLogger;

public class FakeBaseLogger extends BaseLogger {
    public FakeBaseLogger() {
        super();
    }

    public FakeBaseLogger(String host, int port) {
        super(host, port);
    }

    public FakeBaseLogger(String host, int port, String name) {
        super(host, port, name);
    }

    @Override
    protected void createSocket(String host, int port) {
        this.socket = new FakeLoggerSocket(host, port);
    }

    public LogLevel getReportLevel() {
        return reportLevel;
    }

    public String getName() {
        return name;
    }

    public boolean messageWasQueued(LogLevel level, String message) {
        return getSocket()
            .getQueue()
            .stream()
            .filter(m -> m.getLogLevel() == level)
            .filter(m -> m.getMessage().contains(message))
            .count() == 1;
    }

    public long getQueuedMessageCount() {
        return getSocket().getQueue().stream().count();
    }

    private FakeLoggerSocket getSocket() {
        return (FakeLoggerSocket)this.socket;
    }
}
