package ch.hslu.vsk.g01.loggercomponent;

import ch.hslu.loggerinterface.LogLevel;
import ch.hslu.vsk.g01.loggercomponent.fakes.FakeBaseLogger;
import org.junit.Test;

import static java.lang.Thread.sleep;
import static org.junit.Assert.*;

public class BaseLoggerTest {

    @Test
    public void the_default_report_level_is_debug() {
        // Arrange
        FakeBaseLogger logger = new FakeBaseLogger();

        // Assert
        assertEquals(LogLevel.DEBUG, logger.getReportLevel());
    }

    @Test
    public void the_logger_name_can_be_set_or_otherwise_default_will_be_used() {
        // Arrange
        FakeBaseLogger defaultLogger = new FakeBaseLogger("127.0.0.1", 54321);
        FakeBaseLogger demoLogger = new FakeBaseLogger("127.0.0.1", 54321, "Demo");

        // Assert
        assertEquals("Default", defaultLogger.getName());
        assertEquals("Demo", demoLogger.getName());
    }

    @Test
    public void the_report_level_is_stored_properly() {
        // Arrange
        FakeBaseLogger logger = new FakeBaseLogger();

        // PreAssert
        assertEquals(LogLevel.DEBUG, logger.getReportLevel());

        // Act
        logger.setReportLevel(LogLevel.ERROR);

        // Assert
        assertEquals(LogLevel.ERROR, logger.getReportLevel());
    }

    @Test
    public void a_message_can_be_logged() {
        // Arrange
        FakeBaseLogger logger = new FakeBaseLogger();

        // Act
        logger.log(LogLevel.DEBUG, "A debug message");

        // Assert
        assertTrue(logger.messageWasQueued(LogLevel.DEBUG, "A debug message"));
        assertFalse(logger.messageWasQueued(LogLevel.ERROR, "A debug message"));
        assertFalse(logger.messageWasQueued(LogLevel.DEBUG, "A random message"));
    }

    @Test
    public void a_throwable_can_be_logged() {
        // Arrange
        FakeBaseLogger logger = new FakeBaseLogger();

        // Act
        logger.log(LogLevel.INFO, new Throwable("A throwable"));

        try {
            sleep(100);
        } catch (InterruptedException e) {
            fail("Test failed because of InterruptedException");
        }

        // Assert
        assertTrue(logger.messageWasQueued(LogLevel.INFO, "A throwable"));
        assertFalse(logger.messageWasQueued(LogLevel.ERROR, "A throwable"));
        assertFalse(logger.messageWasQueued(LogLevel.INFO, "Another throwable"));
    }


    @Test
    public void the_logger_checks_the_reportLevel_before_sending() {
        // Arrange
        FakeBaseLogger logger = new FakeBaseLogger();

        // Act
        logger.log(LogLevel.DEBUG, "debug message #1");
        logger.log(LogLevel.INFO, "info message #1");
        logger.log(LogLevel.ERROR, "error message #1");
        logger.setReportLevel(LogLevel.INFO);
        logger.log(LogLevel.DEBUG, "debug message #2");
        logger.log(LogLevel.INFO, "info message #2");
        logger.log(LogLevel.ERROR, "error message #2");

        // Assert
        assertEquals(5, logger.getQueuedMessageCount());
        assertTrue(logger.messageWasQueued(LogLevel.DEBUG, "debug message #1"));
        assertTrue(logger.messageWasQueued(LogLevel.INFO, "info message #1"));
        assertTrue(logger.messageWasQueued(LogLevel.ERROR, "error message #1"));
        assertFalse(logger.messageWasQueued(LogLevel.DEBUG, "debug message #2"));
        assertTrue(logger.messageWasQueued(LogLevel.INFO, "info message #2"));
        assertTrue(logger.messageWasQueued(LogLevel.ERROR, "error message #2"));
    }
}