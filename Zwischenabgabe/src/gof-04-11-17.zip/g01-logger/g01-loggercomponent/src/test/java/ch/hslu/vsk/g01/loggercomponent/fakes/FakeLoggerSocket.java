package ch.hslu.vsk.g01.loggercomponent.fakes;

import ch.hslu.loggerinterface.LogLevel;
import ch.hslu.vsk.g01.loggercommon.LogMessage;
import ch.hslu.vsk.g01.loggercomponent.LoggerSocket;

import java.util.concurrent.BlockingQueue;

public class FakeLoggerSocket extends LoggerSocket {
    public FakeLoggerSocket(String host, int port) {
        super(host, port);
    }

    @Override
    public void start() {

    }

    public BlockingQueue<LogMessage> getQueue() {
        return queue;
    }
}
