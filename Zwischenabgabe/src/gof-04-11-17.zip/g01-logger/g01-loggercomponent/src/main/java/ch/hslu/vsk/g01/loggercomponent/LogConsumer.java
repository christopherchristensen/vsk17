package ch.hslu.vsk.g01.loggercomponent;

import ch.hslu.vsk.g01.loggercommon.LogMessage;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;

/**
 * Reads a message from the queue and sends it to the server
 */
public class LogConsumer implements Runnable {

    private BlockingQueue<LogMessage> queue;
    private String host;
    private int port;

    public LogConsumer(String host, int port, BlockingQueue<LogMessage> queue) {
        this.queue = queue;
        this.host = host;
        this.port = port;
    }

    @Override
    public void run() {

        while (true) {
            try (Socket client = new Socket(host, port)) {
                final ObjectOutputStream outStream = new ObjectOutputStream(client.getOutputStream());

                while (client.isConnected()) {
                    LogMessage message;
                    synchronized (LoggerSocket.queueLock) {
                        while (queue.isEmpty()) {
                            LoggerSocket.queueLock.wait();
                        }
                        message = queue.take();
                    }
                    outStream.writeObject(message);
                }
            } catch (InterruptedException | IOException e) {
                e.printStackTrace();
            }

            // TODO log that connection lost!
        }
    }
}
