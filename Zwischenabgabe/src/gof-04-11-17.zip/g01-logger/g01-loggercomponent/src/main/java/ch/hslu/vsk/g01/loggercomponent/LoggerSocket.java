package ch.hslu.vsk.g01.loggercomponent;

import ch.hslu.loggerinterface.LogLevel;
import ch.hslu.vsk.g01.loggercommon.LogMessage;

import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * This class provides a connection to the server. A seperate Thread is created to read the queue and send it
 */
public class LoggerSocket{
    private String host;
    private int port;


    protected BlockingQueue<LogMessage> queue = new LinkedBlockingQueue<>();
    public static final Object queueLock = new Object();

    public LoggerSocket(String host, int port){
        this.host = host;
        this.port = port;
    }

    public void start() {
        LogConsumer consumer = new LogConsumer(host, port, queue);
        new Thread(consumer).start();
    }

    public void queueLogMessage(LogMessage message){
        LogProducer producer = new LogProducer(queue, message);
        new Thread(producer).start();
    }
}
