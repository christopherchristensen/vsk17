package ch.hslu.vsk.g01.loggercomponent;

import ch.hslu.loggerinterface.LogLevel;
import ch.hslu.loggerinterface.Logger;
import ch.hslu.vsk.g01.loggercommon.LogMessage;

public class BaseLogger implements Logger{
    protected LogLevel reportLevel;
    protected LoggerSocket socket;
    protected String name;

    public BaseLogger() {
        this("127.0.0.1", 54321, "Default");
    }

    public BaseLogger(String host, int port) {
        this(host, port, "Default");
    }

    public BaseLogger(String host, int port, String name) {
        this.name = name;
        this.reportLevel = LogLevel.DEBUG;

        createSocket(host, port);
    }

    @Override
    public void setReportLevel(LogLevel logLevel) {
        this.reportLevel = logLevel;
    }

    @Override
    public void log(LogLevel logLevel, String s) {
        if (reportLevel.getCode() <= logLevel.getCode()){
            socket.queueLogMessage(new LogMessage(logLevel, "["+name+"] " + s));
        }
    }

    @Override
    public void log(LogLevel logLevel, Throwable throwable) {
        String message = String.format("Throwable: %s",
            throwable.getMessage()
        );
        log(logLevel, message);
    }

    protected void createSocket(String host, int port) {
        socket = new LoggerSocket(host, port);
        socket.start();
    }
}
