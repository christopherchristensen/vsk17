package ch.hslu.vsk.g01.loggercomponent;

import ch.hslu.loggerinterface.Logger;
import ch.hslu.loggerinterface.LoggerSetup;

public class LoggerFactory implements LoggerSetup {

    @Override
    public Logger createLogger(String host, int port) {
        return new BaseLogger(host, port);
    }

    @Override
    public Logger createLogger(String host, int port, String name) {
        return new BaseLogger(host, port, name);
    }
}
