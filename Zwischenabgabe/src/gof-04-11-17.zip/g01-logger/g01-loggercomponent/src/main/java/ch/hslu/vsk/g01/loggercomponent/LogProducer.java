package ch.hslu.vsk.g01.loggercomponent;

import ch.hslu.vsk.g01.loggercommon.LogMessage;

import java.util.concurrent.BlockingQueue;
import java.util.logging.Logger;

/**
 * Puts a message into the queue
 */
public class LogProducer implements Runnable {

    private BlockingQueue<LogMessage> queue;
    private LogMessage message;

    public LogProducer(BlockingQueue<LogMessage> queue, LogMessage message){
        this.queue = queue;
        this.message = message;
    }

    @Override
    public void run() {
        try {
            synchronized (LoggerSocket.queueLock) {
                queue.put(message);
                LoggerSocket.queueLock.notifyAll();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
