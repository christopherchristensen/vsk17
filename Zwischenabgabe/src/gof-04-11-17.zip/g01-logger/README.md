[![Build Status](https://jenkins-vsk.el.eee.intern/jenkins/job/g01-logger/badge/icon)](https://jenkins-vsk.el.eee.intern/jenkins/job/g01-logger)

# Logger

Implementation des Loggers von VSK-17HS.