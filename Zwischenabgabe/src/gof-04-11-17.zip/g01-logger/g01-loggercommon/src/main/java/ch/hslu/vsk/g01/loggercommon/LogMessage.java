package ch.hslu.vsk.g01.loggercommon;

import ch.hslu.loggerinterface.LogLevel;

import java.io.Serializable;
import java.time.Instant;

public class LogMessage implements Serializable {

    private LogLevel level;
    private String message;
    private Instant createdAt;
    private Instant receivedAt;

    public LogMessage(LogLevel level, String message) {
        this.level = level;
        this.message = message;
        this.createdAt = Instant.now();
        this.receivedAt = null;
    }

    public LogLevel getLogLevel() {
        return this.level;
    }

    public String getMessage() {
        return this.message;
    }

    public Instant getCreatedAt() {
        return this.createdAt;
    }

    public Instant getReceivedAt() {
        return this.receivedAt;
    }

    public void setReceived() {
        receivedAt = Instant.now();
    }
}
