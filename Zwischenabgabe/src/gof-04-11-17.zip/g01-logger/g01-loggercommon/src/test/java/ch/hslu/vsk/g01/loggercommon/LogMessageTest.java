package ch.hslu.vsk.g01.loggercommon;

import ch.hslu.loggerinterface.LogLevel;
import org.junit.Test;

import static org.junit.Assert.*;

public class LogMessageTest {
    @Test
    public void log_level_and_message_will_be_stored_internal() {
        // Arrange
        LogMessage message = new LogMessage(LogLevel.DEBUG, "Lorem ipsum");

        // Assert
        assertEquals(LogLevel.DEBUG, message.getLogLevel());
        assertEquals("Lorem ipsum", message.getMessage());
    }

    @Test
    public void the_created_at_date_is_set_after_construction() {
        // Arrange
        LogMessage message = new LogMessage(LogLevel.DEBUG, "Lorem ipsum");

        // Assert
        assertNotNull(message.getCreatedAt());
    }

    @Test
    public void the_received_at_date_is_set_to_null_during_construction() {
        // Arrange
        LogMessage message = new LogMessage(LogLevel.DEBUG, "Lorem ipsum");

        // Assert
        assertNull(message.getReceivedAt());
    }

    @Test
    public void the_received_at_date_is_set_after_setReceived_is_called() {
        // Arrange
        LogMessage message = new LogMessage(LogLevel.DEBUG, "Lorem ipsum");

        // PreAssert
        assertNull(message.getReceivedAt());

        // Act
        message.setReceived();

        // Assert
        assertNotNull(message.getReceivedAt());
    }
}