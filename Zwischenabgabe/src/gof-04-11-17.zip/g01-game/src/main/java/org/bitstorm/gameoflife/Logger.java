package org.bitstorm.gameoflife;

import ch.hslu.loggerinterface.LogLevel;
import ch.hslu.loggerinterface.LoggerFactory;
import ch.hslu.loggerinterface.LoggerSetup;

final class Logger {
    private static ch.hslu.loggerinterface.Logger instance;

    static void start() {
        String fqn = "ch.hslu.vsk.g01.loggercomponent.LoggerFactory";
        String server = "127.0.0.1";
        Integer port = 54321;

        try {
            LoggerSetup loggerFactory = LoggerFactory.getLoggerSetup(fqn);
            instance = loggerFactory.createLogger(server, port);
            instance.setReportLevel(LogLevel.INFO);
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException e) {
            // TODO: Implement error handling
        }
    }

    static void log(LogLevel level, String message) {
        if (instance != null) {
            instance.log(level, message);
        }
    }

    static void log(LogLevel level, Throwable throwable) {
        if (instance != null) {
            instance.log(level, throwable);
        }
    }
}
