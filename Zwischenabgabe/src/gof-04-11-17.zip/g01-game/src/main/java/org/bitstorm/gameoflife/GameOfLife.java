/**
 * Game of Life v1.4 Copyright 1996-2004 Edwin Martin <edwin@bitstorm.nl>
 * version 1.0 online since July 3 1996 Changes: 1.1: Double buffering to
 * screen; faster paint 1.2: Arrowkeys changed; better use of `synchronized'
 * 1.3: Choose speed from drop down menu and draw with mouse 1.4: Use Java 1.1
 * events, remove 13 deprecated methods, some refactoring. 2003-11-08 1.5: Lots
 * of refactoring, zooming, small improvements
 *
 * @author Edwin Martin
 *
 */
package org.bitstorm.gameoflife;

import ch.hslu.loggerinterface.LogLevel;

import java.applet.Applet;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

/**
 * The Game Of Life Applet. This is the heart of the program. It initializes
 * everything en put it together.
 *
 * @author Edwin Martin
 */
public class GameOfLife extends Applet implements Runnable, GameOfLifeControlsListener {

    protected CellGridCanvas gameOfLifeCanvas;
    protected GameOfLifeGrid gameOfLifeGrid;
    protected int cellSize;
    protected int cellCols;
    protected int cellRows;
    protected int genTime;
    protected GameOfLifeControls controls;
    protected static Thread gameThread = null;

    /**
     * Initialize UI.
     *
     * @see java.applet.Applet#init()
     */
    @Override
    public void init() {
        Logger.start();

        Logger.log(LogLevel.INFO, "Initializing UI...");
        getParams();

        // set background colour
        Color c = new Color(0x999999);
        Logger.log(LogLevel.DEBUG, "Set the background colour to " + c.toString());
        setBackground(c);

        // create gameOfLifeGrid
        Logger.log(LogLevel.DEBUG, String.format("Create the grid with cellCols: %d, cellRows: %d.", cellCols, cellRows));
        gameOfLifeGrid = new GameOfLifeGrid(cellCols, cellRows);
        gameOfLifeGrid.clear();

        // create GameOfLifeCanvas
        Logger.log(LogLevel.DEBUG, String.format("Create the canvas with cellSize: %d, ", cellSize));
        gameOfLifeCanvas = new CellGridCanvas(gameOfLifeGrid, cellSize);

        // create GameOfLifeControls
        Logger.log(LogLevel.DEBUG, "Initialize controls.");
        controls = new GameOfLifeControls();
        controls.addGameOfLifeControlsListener(this);

        // put it all together
        Logger.log(LogLevel.DEBUG, "Put it all together.");
        GridBagLayout gridbag = new GridBagLayout();
        setLayout(gridbag);
        GridBagConstraints canvasContraints = new GridBagConstraints();

        canvasContraints.fill = GridBagConstraints.BOTH;
        canvasContraints.gridx = GridBagConstraints.REMAINDER;
        canvasContraints.gridy = 0;
        canvasContraints.weightx = 1;
        canvasContraints.weighty = 1;
        canvasContraints.anchor = GridBagConstraints.CENTER;
        gridbag.setConstraints(gameOfLifeCanvas, canvasContraints);
        add(gameOfLifeCanvas);

        GridBagConstraints controlsContraints = new GridBagConstraints();
        canvasContraints.gridy = 1;
        canvasContraints.gridx = 0;
        controlsContraints.gridx = GridBagConstraints.REMAINDER;
        gridbag.setConstraints(controls, controlsContraints);
        add(controls);

        try {
            // Start with a shape (My girlfriend clicked "Start" on a blank screen and wondered why nothing happened).
            Logger.log(LogLevel.DEBUG, "Start with a shape.");
            setShape(ShapeCollection.getShapeByName("Glider"));
        } catch (ShapeException e) {
            // Ignore. Not going to happen.
        }
        setVisible(true);
        validate();

        Logger.log(LogLevel.INFO, "...done initializing UI.");
    }

    /**
     * Get params (cellSize, cellCols, cellRows, genTime) from applet-tag
     */
    protected void getParams() {
        Logger.log(LogLevel.DEBUG, "Getting params (cellSize, cellCols, cellRows, genTime) from applet-tag.");
        cellSize = getParamInteger("cellsize", 11);
        cellCols = getParamInteger("cellcols", 50);
        cellRows = getParamInteger("cellrows", 30);
        genTime = getParamInteger("gentime", 1000);
        Logger.log(LogLevel.DEBUG, String.format("Params set to (%d, %d, %d, %d).", cellSize, cellCols, cellRows, genTime));
    }

    /**
     * Read applet parameter (int) or, when unavailable, get default value.
     *
     * @param name name of parameter
     * @param defaultParam default when parameter is unavailable
     * @return value of parameter
     */
    protected int getParamInteger(String name, int defaultParam) {
        String param;
        int paramInt;

        param = getParameter(name);
        if (param == null) {
            paramInt = defaultParam;
            Logger.log(LogLevel.DEBUG, String.format("Using default parameter for %s.", name));
        } else {
            paramInt = Integer.valueOf(param).intValue();
            Logger.log(LogLevel.DEBUG, String.format("Using %d for %s.", paramInt, name));
        }
        return paramInt;
    }

    /**
     * Starts creating new generations.
     * No start() to prevent starting immediately.
     */
    public synchronized void start2() {
        Logger.log(LogLevel.DEBUG, "Start creating new generations.");
        controls.start();
        if (gameThread == null) {
            gameThread = new Thread(this);
            gameThread.start();
        }
    }

    /**
     * @see java.applet.Applet#stop()
     */
    @Override
    public void stop() {
        Logger.log(LogLevel.DEBUG, "Applet is being stopped.");
        controls.stop();
        gameThread = null;
    }

    /**
     * @see java.lang.Runnable#run()
     */
    @Override
    public synchronized void run() {
        while (gameThread != null) {
            nextGeneration();
            try {
                Thread.sleep(genTime);
            } catch (InterruptedException e) {
                Logger.log(LogLevel.CRITICAL, "GameOfLife.Run() has been interrupted unexpectedly!");
                Logger.log(LogLevel.CRITICAL, e);
                e.printStackTrace();
            }
        }
    }

    /**
     * Is the applet running?
     *
     * @return true: applet is running
     */
    public boolean isRunning() {
        return gameThread != null;
    }

    /**
     * Go to the next generation.
     */
    public void nextGeneration() {
        gameOfLifeGrid.next();
        gameOfLifeCanvas.repaint();
        showGenerations();
    }

    /**
     * Set the new shape
     *
     * @param shape name of shape
     */
    public void setShape(Shape shape) {
        if (shape == null) {
            return;
        }
        Logger.log(LogLevel.DEBUG, String.format("Set the new shape to %s.", shape.getName()));
        try {
            gameOfLifeCanvas.setShape(shape);
            reset();
        } catch (ShapeException e) {
            Logger.log(LogLevel.WARNING, String.format("Shape %s couldn't be set.", shape.getName()));
            Logger.log(LogLevel.DEBUG, e);
            alert(e.getMessage());
        }
    }

    /**
     * Resets applet (after loading new shape)
     */
    public void reset() {
        Logger.log(LogLevel.DEBUG, "Resetting applet after loading new shape.");
        stop(); // might otherwise confuse user
        gameOfLifeCanvas.repaint();
        showGenerations();
        showStatus("");
    }

    /**
     * @see java.applet.Applet#getAppletInfo()
     */
    @Override
    public String getAppletInfo() {
        return "Game Of Life v. 1.5\nCopyright 1996-2004 Edwin Martin";
    }

    /**
     * Show number of generations.
     */
    private void showGenerations() {
        Logger.log(LogLevel.DEBUG, String.format("Show number of generations on UI: %d", gameOfLifeGrid.getGenerations()));
        controls.setGeneration(gameOfLifeGrid.getGenerations());
    }

    /**
     * Set speed of new generations.
     *
     * @param fps generations per second
     */
    public void setSpeed(int fps) {
        Logger.log(LogLevel.DEBUG, String.format("Setting speed of new generations to %d.", fps));
        genTime = fps;
    }

    /**
     * Sets cell size.
     *
     * @param p size of cell in pixels
     */
    public void setCellSize(int p) {
        Logger.log(LogLevel.DEBUG, String.format("Setting cell size to %d pixels.", p));
        cellSize = p;
        gameOfLifeCanvas.setCellSize(cellSize);
    }

    /**
     * Gets cell size.
     *
     * @return size of cell
     */
    public int getCellSize() {
        return cellSize;
    }

    /**
     * Shows an alert
     *
     * @param s text to show
     */
    public void alert(String s) {
        Logger.log(LogLevel.INFO, String.format("Show an alert with the following text: %s", s));
        showStatus(s);
    }

    /**
     * Callback from GameOfLifeControlsListener
     *
     * @see
     * org.bitstorm.gameoflife.GameOfLifeControlsListener#startStopButtonClicked(org.bitstorm.gameoflife.GameOfLifeControlsEvent)
     */
    @Override
    public void startStopButtonClicked(GameOfLifeControlsEvent e) {
        if (isRunning()) {
            Logger.log(LogLevel.INFO, "Stop was clicked.");
            stop();
        } else {
            Logger.log(LogLevel.INFO, "Start was clicked.");
            start2();
        }
    }

    /**
     * Callback from GameOfLifeControlsListener
     *
     * @see
     * org.bitstorm.gameoflife.GameOfLifeControlsListener#nextButtonClicked(org.bitstorm.gameoflife.GameOfLifeControlsEvent)
     */
    @Override
    public void nextButtonClicked(GameOfLifeControlsEvent e) {
        Logger.log(LogLevel.INFO, "Next was clicked.");
        nextGeneration();
    }

    /**
     * Callback from GameOfLifeControlsListener
     *
     * @see
     * org.bitstorm.gameoflife.GameOfLifeControlsListener#speedChanged(org.bitstorm.gameoflife.GameOfLifeControlsEvent)
     */
    @Override
    public void speedChanged(GameOfLifeControlsEvent e) {
        Logger.log(LogLevel.INFO, String.format("Speed was changed. New speed: %d", e.getSpeed()));
        setSpeed(e.getSpeed());
    }

    /**
     * Callback from GameOfLifeControlsListener
     *
     * @see
     * org.bitstorm.gameoflife.GameOfLifeControlsListener#speedChanged(org.bitstorm.gameoflife.GameOfLifeControlsEvent)
     */
    @Override
    public void zoomChanged(GameOfLifeControlsEvent e) {
        Logger.log(LogLevel.INFO, String.format("Zoom was changed. New zoom: %d", e.getZoom()));
        setCellSize(e.getZoom());
    }

    /**
     * Callback from GameOfLifeControlsListener
     *
     * @see
     * org.bitstorm.gameoflife.GameOfLifeControlsListener#shapeSelected(org.bitstorm.gameoflife.GameOfLifeControlsEvent)
     */
    @Override
    public void shapeSelected(GameOfLifeControlsEvent e) {
        String shapeName = (String) e.getShapeName();
        Logger.log(LogLevel.INFO, String.format("Shape %s was selected.", shapeName));
        Shape shape;
        try {
            shape = ShapeCollection.getShapeByName(shapeName);
            setShape(shape);
        } catch (ShapeException e1) {
            // Ignore. Not going to happen.
        }
    }
}
