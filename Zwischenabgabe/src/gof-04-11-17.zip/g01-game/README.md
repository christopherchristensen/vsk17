[![Build Status](https://jenkins-vsk.el.eee.intern/jenkins/job/g01-game/badge/icon)](https://jenkins-vsk.el.eee.intern/jenkins/job/g01-game)

# GameOfLife

Applikation für Integration des Loggers von VSK-17HS.