#!/bin/sh
java -cp game.jar:loggercomponent.jar:loggerinterface.jar:loggercommon.jar:stringpersistor-api.jar:stringpersistor.jar "org.bitstorm.gameoflife.StandaloneGameOfLife"
