#!/bin/sh
java -cp loggerserver.jar:loggercommon.jar:stringpersistor-api.jar:stringpersistor.jar:loggerinterface.jar "ch.hslu.vsk.g01.loggerserver.LoggerServer"
