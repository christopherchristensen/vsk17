#!/bin/sh
java -cp loggerviewer.jar:loggerinterface.jar:loggercommon.jar "ch.hslu.vsk.g01.loggerviewer.LoggerViewer"
